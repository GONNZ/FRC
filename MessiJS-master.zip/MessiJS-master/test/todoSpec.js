
describe('Use Messi.load() to show an ajax response', function() {
    it('TBD: show an Ajax response');
});

describe('Code Coverage reveals that', function() {
    it('options.width is not tested');
    it('messi.parent().length > 0 is not tested');
    it('options.after is not tested');
    it('messi.animate with options.modal is not tested');
    it('messi.animate with options.unload not defined is not tested');
    it('resize with options.center is not tested');
});
